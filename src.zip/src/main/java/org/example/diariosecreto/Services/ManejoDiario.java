package org.example.diariosecreto.Services;

import org.example.diariosecreto.Models.Diario;

public interface ManejoDiario {

    public String guardarDiario(Diario diario);
}
